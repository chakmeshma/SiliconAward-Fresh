<?php 

class ModelPaymentMelli extends Model
{
	public function getMethod($address)
	{
		$this->load->language('payment/melli');

		if ($this->config->get('melli_status')) {

			$status = true;

		} else {

			$status = false;
		}

		$method_data = array ();

		if ($status) {

			$method_data = array (
        		'code' => 'melli',
        		'title' => $this->language->get('text_title'),
				'terms' => '',
				'sort_order' => $this->config->get('melli_sort_order')
			);
		}

		return $method_data;
	}
}