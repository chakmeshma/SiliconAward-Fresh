<?php

	class ControllerPaymentMelli extends Controller {
		public function index() {
			$this->load->language('payment/melli');
			$this->load->model('checkout/order');
			$this->load->library('encryption');

			$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

			$data['button_confirm'] = $this->language->get('button_confirm');

			$data['error_warning'] = false;

			if (extension_loaded('curl')) {

				$amount = $this->get_price_in_rail($order_info);
				$redirect = $this->url->link('payment/melli/callback', '', '', 'SSL');

				$terminal_id = $this->config->get('melli_terminal_id');
				$merchant_id = $this->config->get('melli_merchant_id');
				$terminal_key = $this->config->get('melli_terminal_key');
				$sign_data = $this->sadad_encrypt($terminal_id . ';' . $order_info['order_id'] . ';' . $amount, $terminal_key);


				$parameters = array(
						'MerchantID' => $merchant_id,
						'TerminalId' => $terminal_id,
						'Amount' => $amount,
						'OrderId' => $order_info['order_id'],
						'LocalDateTime' => date('Ymdhis'),
						'ReturnUrl' => $redirect,
						'SignData' => $sign_data,
				);

				$result = $this->sadad_call_api('https://sadad.shaparak.ir/VPG/api/v0/Request/PaymentRequest', $parameters);
				if ($result != false) {
					if ($result->ResCode == 0) {
						$data['action'] = 'https://sadad.shaparak.ir/VPG/Purchase?Token=' . $result->Token;
					} else {
						$message = $this->language->get('error_head');
						$message .= $this->language->get('error_request_' . $result->ResCode);
						$data['error_warning'] = $message;

					}
				} else {
					$message = $this->language->get('error_request');
					$data['error_warning'] = $message;
				}


			} else {

				$data['error_warning'] = $this->language->get('error_curl');
			}

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/melli.tpl')) {

				return $this->load->view($this->config->get('config_template') . '/template/payment/melli.tpl', $data);

			} else {

				return $this->load->view('default/template/payment/melli.tpl', $data);
			}
		}

		public function callback() {
			$this->load->language('payment/melli');
			$this->load->model('checkout/order');
			$this->load->library('encryption');

			$this->document->setTitle($this->language->get('heading_title'));

			$order_id = isset($this->session->data['order_id']) ? $this->session->data['order_id'] : false;

			$order_info = $this->model_checkout_order->getOrder($order_id);

			$data['heading_title'] = $this->language->get('heading_title');

			$data['button_continue'] = $this->language->get('button_continue');
			$data['continue'] = $this->url->link('common/home', '', 'SSL');

			$data['error_warning'] = false;

			$data['continue'] = $this->url->link('checkout/cart', '', 'SSL');

			if ($this->request->post['OrderId'] && $this->request->post['token']) {
				if ($this->request->post['ResCode'] == "0") {
					$token = $_POST['token'];
					//verify payment
					$parameters = array(
							'Token' => $token,
							'SignData' => self::sadad_encrypt($token, $this->config->get('melli_terminal_key')),
					);

					$result = $this->sadad_call_api('https://sadad.shaparak.ir/VPG/api/v0/Advice/Verify', $parameters);
					if ($result != false) {
						if ($result->ResCode == 0) {
							$amount = $this->get_price_in_rail($order_info);

							if ($amount == $result->Amount) {

								$comment = $this->language->get('text_transaction') . $result->SystemTraceNo;
								$comment .= '<br/>' . $this->language->get('text_transaction_reference') . $result->RetrivalRefNo;

								$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('melli_order_status_id'), $comment);

							} else {
								$data['error_warning'] = $this->language->get('error_amount');
							}

						} else {
							$data['error_warning'] = $this->language->get('error_payment');

						}
					} else {
						$data['error_warning'] = $this->language->get('error_payment');

					}


				} else {
					$data['error_warning'] = $this->language->get('error_payment');
				}

			} else {
				$data['error_warning'] = $this->language->get('error_data');
			}

			if ($data['error_warning']) {

				$data['breadcrumbs'] = array();

				$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_home'),
						'href' => $this->url->link('common/home', '', 'SSL'),
						'separator' => false
				);

				$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_basket'),
						'href' => $this->url->link('checkout/cart', '', 'SSL'),
						'separator' => ' » '
				);

				$data['breadcrumbs'][] = array(
						'text' => $this->language->get('text_checkout'),
						'href' => $this->url->link('checkout/checkout', '', 'SSL'),
						'separator' => ' » '
				);

				$data['header'] = $this->load->controller('common/header');
				$data['footer'] = $this->load->controller('common/footer');

				if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/melli_callback.tpl')) {

					$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/payment/melli_callback.tpl', $data));

				} else {

					$this->response->setOutput($this->load->view('default/template/payment/melli_callback.tpl', $data));
				}

			} else {

				$this->response->redirect($this->url->link('checkout/success', '', 'SSL'));
			}
		}

		private function sadad_encrypt($data, $secret) {
			//Generate a key from a hash
			$key = base64_decode($secret);

			//Pad for PKCS7
			$blockSize = mcrypt_get_block_size('tripledes', 'ecb');
			$len = strlen($data);
			$pad = $blockSize - ($len % $blockSize);
			$data .= str_repeat(chr($pad), $pad);

			//Encrypt data
			$encData = mcrypt_encrypt('tripledes', $key, $data, 'ecb');

			return base64_encode($encData);
		}

		private function sadad_call_api($url, $data = false) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=utf-8'));
			curl_setopt($ch, CURLOPT_POST, 1);
			if ($data) {
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
			}
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$result = curl_exec($ch);
			curl_close($ch);
			return !empty($result) ? json_decode($result) : false;
		}

		private function get_price_in_rail($order_info) {
			$amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
			$currency = $order_info['currency_code'];
			$rate = 0;
			if ($currency == 'RLS') {
				$rate = 1;
			} elseif ($currency == 'TOM') {
				$rate = 10;
			}
			return $amount * $rate;
		}


	}

?>
